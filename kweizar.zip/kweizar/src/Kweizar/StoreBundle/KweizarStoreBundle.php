<?php

namespace Kweizar\StoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KweizarStoreBundle extends Bundle
{
}
