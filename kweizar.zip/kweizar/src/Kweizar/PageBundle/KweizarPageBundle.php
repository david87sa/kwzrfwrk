<?php

namespace Kweizar\PageBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KweizarPageBundle extends Bundle
{
}
