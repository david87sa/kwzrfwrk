<?php

/* KweizarPageBundle:Publish/components:element.html.twig */
class __TwigTemplate_161bf8f414120b9640643f0dada0584a47807f6ca2f4785780340cb07b7cc68e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<div id=\"element-";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["newsitem"]) ? $context["newsitem"] : $this->getContext($context, "newsitem")), "id"), "html", null, true);
        echo "\" class=\"element\" elementId=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["newsitem"]) ? $context["newsitem"] : $this->getContext($context, "newsitem")), "id"), "html", null, true);
        echo "\">
    <div class=\"image\"><img id=\"";
        // line 4
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["newsitem"]) ? $context["newsitem"] : $this->getContext($context, "newsitem")), "title"), array(" " => "")), "html", null, true);
        echo "\" class=\"imgSrc videoImg\" src=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["newsitem"]) ? $context["newsitem"] : $this->getContext($context, "newsitem")), "imgSrc"), "html", null, true);
        echo "\"/></div>
    <div class=\"content\">
        <div class=\"title\">";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["newsitem"]) ? $context["newsitem"] : $this->getContext($context, "newsitem")), "title"), "html", null, true);
        echo "</div>
        <div class=\"description\">";
        // line 7
        echo $this->getAttribute((isset($context["newsitem"]) ? $context["newsitem"] : $this->getContext($context, "newsitem")), "Description");
        echo "</div>
        <a href=\"#\" class=\"see_more\">See More</a>
    </div>
    
    <div class=\"link invisible\" destinationType=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["newsitem"]) ? $context["newsitem"] : $this->getContext($context, "newsitem")), "destinationType"), "html", null, true);
        echo "\">
        ";
        // line 12
        echo $this->getAttribute((isset($context["newsitem"]) ? $context["newsitem"] : $this->getContext($context, "newsitem")), "destinationContent");
        echo "
    </div>
</div>
        

";
    }

    public function getTemplateName()
    {
        return "KweizarPageBundle:Publish/components:element.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 12,  46 => 11,  39 => 7,  35 => 6,  28 => 4,  22 => 3,  19 => 2,);
    }
}
