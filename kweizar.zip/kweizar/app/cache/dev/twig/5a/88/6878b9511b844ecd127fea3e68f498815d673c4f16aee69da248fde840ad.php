<?php

/* KweizarPageBundle:Publish/components:home.html.twig */
class __TwigTemplate_5a886878b9511b844ecd127fea3e68f498815d673c4f16aee69da248fde840ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "<div id=\"section";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\" class=\"homecontainer container movable elem";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\">
    <div id=\"logo\" class=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\">
    </div>
    <div id=\"toolbar\" class=\"\">
        <div class=\"imgleft\"></div>
        <div id=\"toolbarContent\">
        <img class=\"nodisplay logosmall\" src=\"../img/kweizarlogo2.png\"/>
            <ul>
            ";
        // line 10
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["component"]) ? $context["component"] : $this->getContext($context, "component")), 0, array(), "array"), "getSections", array(), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 11
            echo "                <li id=\"elem";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id"), "html", null, true);
            echo "\" class=\"toolbarElement\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "title"), "html", null, true);
            echo "</li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['section'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "            </ul>
        </div>
        <div class=\"imgright\"></div>
        <div id=\"listento\">
            <div id=\"spotifyHC\"><a href=\"https://open.spotify.com/album/6lcUOHUOhJPesaoR8phRYx?si=ez2vQ5sFRnuVh_guPdnXEg\"><img src=\"img/newer/branding/spotifyHC.png\"/></a></div>
            <div id=\"bandcampHC\"><a href=\"https://kweizar.bandcamp.com/album/human-convergence\"><img src=\"img/newer/branding/bandcampHC.png\"/></a></div>
            <div id=\"soundcloudHC\"><a href=\"https://soundcloud.com/kweizar\"><img src=\"img/newer/branding/soundcloudHC.png\"/></a></div>
            <div id=\"youtubeHC\"><a href=\"https://www.youtube.com/watch?v=MhyPlSpPTCM&list=OLAK5uy_khMAkbeUV8xSa8ww_BVa9jdH2AM1yoLdE\"><img src=\"img/newer/branding/youtubeHC.png\"/></a></div>
            <div id=\"applemusicHC\"><a href=\"https://music.apple.com/us/album/human-convergence/1481080368\"><img src=\"img/newer/branding/appleHC.png\"/></a></div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "KweizarPageBundle:Publish/components:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 13,  40 => 11,  36 => 10,  26 => 3,  19 => 2,);
    }
}
