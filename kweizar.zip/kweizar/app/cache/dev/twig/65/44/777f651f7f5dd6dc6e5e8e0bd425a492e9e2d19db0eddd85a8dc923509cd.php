<?php

/* KweizarPageBundle:Publish/components:elementSlider.html.twig */
class __TwigTemplate_6544777f651f7f5dd6dc6e5e8e0bd425a492e9e2d19db0eddd85a8dc923509cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "    \t<div id=\"section";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\" class=\"movable container elem";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\" sectionId=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\">
            <div class=\"sectionHeader\">
                <div class=\"sectionTitle\">";
        // line 4
        echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "title");
        echo "</div>
                <div class=\"sectionSubTitle\">";
        // line 5
        echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "subTitle");
        echo "</div>
            </div>
            <div class=\"sectionContent\">
                <div id=\"newernews\" class=\"newscontrols left\"></div>   
                <div id=\"newsscrollbarcontainer\" class=\"scrollbar\">
                    <div id=\"newscont\" class=\"tab sectioncontainer\" >    
                        ";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "getElements", array(), "method"));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["newsitem"]) {
            // line 12
            echo "                                ";
            $this->env->loadTemplate("KweizarPageBundle:Publish/components:element.html.twig")->display($context);
            // line 13
            echo "                        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['newsitem'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "                    </div>
                </div>
                <div id=\"oldernews\" class=\"newscontrols right\"></div>
            </div>
       </div>
        

";
    }

    public function getTemplateName()
    {
        return "KweizarPageBundle:Publish/components:elementSlider.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 14,  62 => 13,  42 => 11,  70 => 18,  60 => 14,  39 => 8,  29 => 4,  40 => 11,  36 => 10,  26 => 3,  19 => 2,  145 => 31,  131 => 30,  127 => 29,  110 => 28,  106 => 27,  99 => 22,  96 => 21,  90 => 20,  83 => 17,  79 => 16,  75 => 15,  71 => 14,  67 => 13,  63 => 12,  59 => 12,  55 => 12,  51 => 11,  47 => 8,  43 => 9,  38 => 5,  33 => 5,  30 => 3,);
    }
}
