<?php

/* KweizarPageBundle:Publish/components:contact.html.twig */
class __TwigTemplate_abd973ce3e6d38fb777362b30fa195e949dcc834954e40dd6a9cd13a49cdeb0c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"section";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\" class=\"contactcont movable container elem";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\" sectionId=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\">

    <div class=\"sectionHeader\">
        <div class=\"sectionTitle\">";
        // line 4
        echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "title");
        echo "</div>
        <div class=\"sectionSubTitle\">";
        // line 5
        echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "subTitle");
        echo "</div>
    </div>
    <div class=\"sectionContent\">  
        <div id=\"socialLinksContainer\" class=\"contactColumn\">
            <ul>
                ";
        // line 10
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "getElements", array(), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["contact"]) {
            // line 11
            echo "                <li>
                    <a href=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "destinationContent"), "html", null, true);
            echo "\">
                        <img src=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "imgSrc"), "html", null, true);
            echo "\">
                        ";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "title"), "html", null, true);
            echo "
                    </a>
                </li>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['contact'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "            </ul>
        </div>
        <div id=\"contactEmailContainer\" class=\"contactColumn\">
            <div class=\"contactEmailForm\">
                
                ";
        // line 23
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["contactEmailForm"]) ? $context["contactEmailForm"] : $this->getContext($context, "contactEmailForm")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("kweizar_page_contactEmail")));
        echo "
                    ";
        // line 24
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["contactEmailForm"]) ? $context["contactEmailForm"] : $this->getContext($context, "contactEmailForm")), 'errors');
        echo "
                    <div class=\"result\"></div>
                    <div class=\"emailRow\">";
        // line 26
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["contactEmailForm"]) ? $context["contactEmailForm"] : $this->getContext($context, "contactEmailForm")), "subject"), 'row');
        echo "</div>
                    <div class=\"emailRow\">";
        // line 27
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["contactEmailForm"]) ? $context["contactEmailForm"] : $this->getContext($context, "contactEmailForm")), "email"), 'row');
        echo "</div>
                    <div class=\"emailRow\">";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["contactEmailForm"]) ? $context["contactEmailForm"] : $this->getContext($context, "contactEmailForm")), "content"), 'row');
        echo "</div>
                ";
        // line 29
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["contactEmailForm"]) ? $context["contactEmailForm"] : $this->getContext($context, "contactEmailForm")), 'form_end');
        echo "
                </form>
            </div>

        </div>
        <img id=\"contactImage\" src=\"#\">
    </div>

</div>
       
";
    }

    public function getTemplateName()
    {
        return "KweizarPageBundle:Publish/components:contact.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 29,  91 => 28,  87 => 27,  83 => 26,  78 => 24,  74 => 23,  67 => 18,  57 => 14,  53 => 13,  49 => 12,  46 => 11,  42 => 10,  34 => 5,  30 => 4,  19 => 1,);
    }
}
