<?php

/* KweizarPageBundle:Author:index.html_1.twig */
class __TwigTemplate_11a54e9be7cd33b383c8bd179d9b2eba8dd3ccdde2fc2f0e167aa66ff0b261b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->env->loadTemplate("KweizarPageBundle:Publish:index.html.twig")->display($context);
        echo "  

<div id=\"add\" class=\"authorbuttons\"><img src=\"/img/icons/list-add.png\"></div>
<div id=\"editdelete\" class=\"authorbuttons\">
    <div id=\"edit\" ><img src=\"/img/icons/document-edit.png\"></div>
    <div id=\"delete\"><img src=\"/img/icons/edit-clear-list.png\"></div>
</div>
<div id=\"addeditdelete\" class=\"authorbuttons\">
    <div id=\"addChild\"><img src=\"/img/icons/list-add.png\"></div>
    <div id=\"edit\" ><img src=\"/img/icons/document-edit.png\"></div>
    <div id=\"delete\"><img src=\"/img/icons/edit-clear-list.png\"></div>
</div>
    <div id=\"section_form\" class=\"section_form container\">
        <h3>Add Section</h3> 
        ";
        // line 15
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("kweizar_page_section_add"), "attr" => array("id" => "add_section")));
        echo "
            ";
        // line 16
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), 'errors');
        echo "
            ";
        // line 17
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), "title"), 'row');
        echo "
            ";
        // line 18
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), "subTitle"), 'row');
        echo "
            ";
        // line 19
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), "sectionType"), 'row');
        echo "
        ";
        // line 20
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), 'form_end');
        echo "
    </div> 
    <div id=\"element_form\" class=\"element_form container\">
        <h3>Add Element</h3>
        ";
        // line 24
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("kweizar_page_element_add"), "attr" => array("id" => "add_element")));
        echo "
            ";
        // line 25
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), 'errors');
        echo "
            ";
        // line 26
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), "imgSrc"), 'row');
        echo "
            ";
        // line 27
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), "title"), 'row');
        echo "
            ";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), "description"), 'row');
        echo "
            ";
        // line 29
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), "destinationType"), 'row');
        echo "
            ";
        // line 30
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), "destinationContent"), 'row');
        echo "
        ";
        // line 31
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), 'form_end');
        echo "
    </div>

<script>
    AUTHOR.INIT();
</script>
";
    }

    public function getTemplateName()
    {
        return "KweizarPageBundle:Author:index.html_1.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 12,  23 => 4,  70 => 9,  53 => 14,  34 => 6,  198 => 56,  194 => 55,  190 => 54,  186 => 53,  178 => 51,  174 => 50,  170 => 49,  161 => 43,  153 => 41,  134 => 34,  129 => 32,  84 => 18,  65 => 6,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  107 => 36,  61 => 10,  273 => 96,  269 => 94,  254 => 92,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  119 => 42,  102 => 32,  71 => 26,  67 => 25,  63 => 24,  59 => 9,  94 => 28,  89 => 20,  85 => 25,  75 => 27,  68 => 14,  56 => 20,  38 => 6,  26 => 6,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 67,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 35,  121 => 30,  117 => 44,  105 => 22,  91 => 31,  62 => 23,  49 => 7,  87 => 30,  31 => 7,  21 => 2,  25 => 3,  28 => 6,  24 => 1,  19 => 1,  93 => 28,  88 => 19,  78 => 17,  46 => 9,  44 => 17,  27 => 4,  79 => 28,  72 => 16,  69 => 19,  47 => 9,  40 => 16,  37 => 5,  22 => 2,  246 => 90,  157 => 42,  145 => 39,  139 => 45,  131 => 52,  123 => 47,  120 => 40,  115 => 43,  111 => 37,  108 => 36,  101 => 32,  98 => 31,  96 => 31,  83 => 29,  74 => 14,  66 => 24,  55 => 8,  52 => 19,  50 => 13,  43 => 6,  41 => 7,  35 => 8,  32 => 4,  29 => 3,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 52,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 58,  149 => 40,  147 => 58,  144 => 49,  141 => 38,  133 => 55,  130 => 41,  125 => 31,  122 => 43,  116 => 28,  112 => 27,  109 => 34,  106 => 36,  103 => 32,  99 => 31,  95 => 28,  92 => 21,  86 => 28,  82 => 22,  80 => 13,  73 => 19,  64 => 14,  60 => 6,  57 => 11,  54 => 15,  51 => 14,  48 => 18,  45 => 17,  42 => 9,  39 => 9,  36 => 15,  33 => 4,  30 => 5,);
    }
}
