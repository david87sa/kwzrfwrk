<?php

/* KweizarPageBundle:Publish/components:basicSection.html.twig */
class __TwigTemplate_067506ab04eed4d0a819f80e56011c376d174ae2fb1eff6f642c2b28bfeb3e3f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "<div id=\"section";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\" class=\"movable container elem";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\" sectionId=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id"), "html", null, true);
        echo "\">
    <div class=\"sectionHeader\">
        <div class=\"sectionTitle\">";
        // line 4
        echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "title");
        echo "</div>
        <div class=\"sectionSubTitle\">";
        // line 5
        echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "subTitle");
        echo "</div>
    </div>
    <div class=\"sectionContent\">   
                ";
        // line 8
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "getElements", array(), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["contentElement"]) {
            // line 9
            echo "                    <div id=\"element-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contentElement"]) ? $context["contentElement"] : $this->getContext($context, "contentElement")), "id"), "html", null, true);
            echo "\" class=\"basicElement\" elementId=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contentElement"]) ? $context["contentElement"] : $this->getContext($context, "contentElement")), "id"), "html", null, true);
            echo "\">    
                        <div class=\"content\">
                            <div class=\"title\">";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contentElement"]) ? $context["contentElement"] : $this->getContext($context, "contentElement")), "title"), "html", null, true);
            echo "</div>
                            <div class=\"description\">";
            // line 12
            echo $this->getAttribute((isset($context["contentElement"]) ? $context["contentElement"] : $this->getContext($context, "contentElement")), "Description");
            echo "</div>
                        </div>
                        <div class=\"image\"><img class=\"imgSrc\" src=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contentElement"]) ? $context["contentElement"] : $this->getContext($context, "contentElement")), "imgSrc"), "html", null, true);
            echo "\"/></div>
                        <div id=\"destination_content\">";
            // line 15
            echo $this->getAttribute((isset($context["contentElement"]) ? $context["contentElement"] : $this->getContext($context, "contentElement")), "destinationContent");
            echo "</div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['contentElement'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "    </div>
</div>
    
";
    }

    public function getTemplateName()
    {
        return "KweizarPageBundle:Publish/components:basicSection.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 18,  64 => 15,  60 => 14,  55 => 12,  51 => 11,  43 => 9,  39 => 8,  33 => 5,  29 => 4,  19 => 2,);
    }
}
