<?php

/* WebProfilerBundle:Profiler:header.html.twig */
class __TwigTemplate_afe27d9135c984adab286b328535783f7c472b1c47166b1fed6275a948dccbc4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"header\" class=\"clear-fix\">
    <h1>
        <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAA+CAMAAAA/Mg/WAAAAjVBMVEXW1ta/v8Dh4eFgXmE8Oj7j4+PLy8unpqiPjpB4d3nIyMjX19dIRkro6OiYl5lUUlZsa22zsrTy8vLl5eU9Oz9KSEzs7OzBwcGEg4XLy8ybmpy9vb3ExMSxsbLa2tp+fH/Y2Nlxb3JXVVjPz89kYmWkpKXd3d3T09O+vr+LiYzMzMy6urowLjL////v7+/NfgWIAAAAL3RSTlP/////////////////////////////////////////////////////////////AFqlOPcAAAAJdnBBZwAAARMAAAA+AHci3fUAAAeMSURBVHja7Zvneuo4EIbdC65gOqGEEFIs+/4vbzWj5hLF5GySZxef7wcWtqVkXkYzIxmMWiNzu7btjJDMttdbsx6TPmQSbW3Skb2NxszERyB92f5Ymfgx0Sr2x8jEzMinis2xMXHXZFC5OyomXkZuUOyNiMnUITfJ8UfDxCc3yx8FE0TyFwpnopD8hdJm4jlkUOdjmh4XhMm8eyZuTIZ0LCrUfs4CbXTvTPJBHzlVVbogCwrlRFD2nTOZkgE9zqrqCM5SUV0IanvPTIZnzpmSeIbGpsHEce+ZSTCAZEG9ZDaXTESYDe+YiTuUc07gJnIOYQv1vwqziTGZPCWibVifMRl2k7SiOrP2/AJeoncUbxoE5hcXRD4ss356EXUoQYlRlpO6tsrS+JxJTHpaXC7z5sypCtKSJqJM4z8oXkJCfp5JsivLd+Olvo1JP+nMUyxFTm8Myx6rkluq2e2fTCoP8nrg/3SIYBRuZRJ+kHer2eZEXx7BTSrQEa/sU9JSXjdlwnTy6jr6UpwJYJgf1xOdN+gvllXcwKQTYS+iWF2ksyqFaCJyzSM9dqC4nUkQ1F9W+CuLp0lZyvYwE4+0VUD0kMXrHt9XMxFrN6Slad2Q/cVAonr915hsO8uaqmH5/FSdKnECZ9EraSn4mnWeaUbYiLDR72WanaTl0jO6sGlBPi0M45BwSy3auBoGfcULIuEuLct6KEuLCtpJi0lxgNvUgAkdz+iEk+eqmWXm+wr1LOqUCxHqL3ryxnuPtl3ejElYm8TxzJgQPO3Z2PDoWS7kErF/xQmgI/Qwo5yA1vSEI/c83YzEPFzW11UJmiAGamjyUDJzD7sSZSyBgBTSUExE/5UlBjSwk01a2lTtNDMTIXZx3MCxrbhVZ4Ch4uPPCNlKVFOwXvyhTOxLOFFEpKLad5o7vtAjdFQsD2U5tKaQuAm06NhNAMOuQCYvqxKZLCdgKF5ZFVomGHnLhwl0OvDcxECSrp+g3tRKR+n1TLrqhAaqMBJ5OcOGS40HCwHY1AyY0VPTd8A0WuHFtEsQTDEnO75pBg4UPrxHTE+Ar+Blp0bFFCBnwkwD55ggk135AO5fv9Omxa+sls14opjgCHA/HncJO4BjJV0mxwokPeKtQqVUj7yK0yceNySSSiTKFJ+eYBbaokKLXXY+bsaTjELE0TxH9ohdfkeIKKZ4WcA2EAloST/pKzDhAMB9CnaFQnnRMVnuAAUf6qUxYJcJThZVzL9i+0Q06gZVE13FmbIps+VTxwML8cAaPvcf0mDiqcF8YK1urKdIIeCTZ43j8k9ZVWRPyOTAkgw2UAk9qWNyxV6oXbmCUeC1zwQ9A1U0CL0OMOlR8dCynJkeMxQxuy6dq80kAMO5HIxAcrJEeGfE38eiv9FIHmANMAE3kQ0UJBwNkxf0LkGReUuPyTk9Yy3PdFThJB1m0n5MZLPVtotoAkAhcxKa1mdiq8SObdFD3Znh5PFk2WswawUFeHkQdk+6RX2fCZxryoJbr10mWKcqKK8qulxuZSJdIRIFag7tNhP7D5jIwLSGUXVMJv+WidVlsuEF65zXaSoLLTRENKu9DM004RN12ZQYZpIPMBEJLIYXlKFcf0mDqmKSqECDE+SgYfIODJS0TCqs1GbIhJ1CUFppy3U+831CfD0TfTwx+0yw0PHQWVSyYLoiDukeu3Y8KTRMREDqM8mI0CuAUNnm+YYQ69R9YSTxaubmOeVyExNP7aH4OG6fyZTyWKs1liFSL9ZeBmei3goGK13eKfgAfSa5iicycpz4hJmLAk4nW7PSjXm+sGH+DDPhR1WfBH0m6D9OTGJlgsilV9pKGkySVn1y0NZsDyoZFy0mAZHa81ItFbnmIkoVndZNFpG99k1zG8v1ckZkc5hJ5LCyNXAAzodM1vJPyjr2vaiX0HipGRO10Wgk9fKwAqu1TAqo8g60cD08lS0mZnvn9ZSmG+kb6VA48ZtMgu5yeStnFwZcPZPW41lE8iETj5c+KqPsSqb3mjNRUFCARM+kvkJ/VJtJTRpaPBdIYb9oVLF7opXbL9eIE5oisKh9bBOKW5QkxinZgADlBkglDlSPTpdYBmJuQvKOy1qjFkyEkqcdsrJqLRPQkq0aywejzSQnLc0vl0W7zn8kOmWaDRKh7Kt7z9hfK6zruyGxsBL9/sqwcHelt/foE50WvMjXaPDxaATB9vuklsSKyY/I+OSR11Ff2A/vz4tl4DdqC1PxN5hA7tRoj7FlTnQKP3USM//WZ8ou7r14v8QkIhrNBtzEHHhsA4n42+SwRPw7TLSO8jjgJvaAnxPnG5GYuFNb/xqTyGk9Bdzsz3Lq6JOOPqWoDffvFB3P7eaV5Y8xUdWWWBTPFiLrPBOt1nf+3a2ss832xgu2E9Eqdu+ciaqrN4LJEZDMB2bOPTOp/dazjM2cnGd40Go7gu8MB83alQZazMJ6haP4bnmovmqB2i9GikQxUVDmj+wB11iRKCZq+gwrHNFvmnzn7+8POBOlKCODyryx/UYyGHKVYIS/pXXDTyNJNM7fXEdrja84QGSMTFB+3seS++6If5uPMoPclmE1D8x6RPoHDj0oidWaaPMAAAAASUVORK5CYII=\" alt=\"Symfony profiler\">
    </h1>

    <div class=\"search\">
        <form method=\"get\" action=\"http://symfony.com/search\" target=\"_blank\">
            <div class=\"form-row\">
                <label for=\"search-id\">
                    <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAABUElEQVQoz2NgAIJ29iBdD0d7X2cPb+tY2f9MDMjgP2O2hKu7vS8CBlisZUNSMJ3fxRMkXO61wm2ue6I3iB1q8Z8ZriDZFCS03fm/wX+1/xp/TBo8QPxeqf+MUAW+QIFKj/+q/wX/c/3n/i/6Qd/bx943z/Q/K1SBI1D9fKv/AhCn/Wf5L5EHdFGKw39OqAIXoPpOMziX4T9/DFBBnuN/HqhAEtCKCNf/XDA/rZRyAmrpsvrPDVUw3wrkqCiLaewg6TohX1d7X0ffs5r/OaAKfinmgt3t4ulr4+Xg4ANip3j+l/zPArNT4LNOD0pAgWCSOUIBy3+h/+pXbBa5tni0eMx23+/mB1YSYnENroT5Pw/QSOX/mkCo+l/jgo0v2KJA643s8PgAmsMBDCbu/5xALHPB2husxN9uCzsDOgAq5kAoaZVnYMCh5Ky1r88Eh/+iABM8jUk7ClYIAAAAAElFTkSuQmCC\" alt=\"Search on Symfony website\">
                </label>

                <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"Search on Symfony website\">

                <button type=\"submit\" class=\"sf-button\">
                    <span class=\"border-l\">
                        <span class=\"border-r\">
                            <span class=\"btn-bg\">OK</span>
                        </span>
                    </span>
                </button>
            </div>
       </form>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:header.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  462 => 202,  449 => 198,  446 => 197,  441 => 196,  439 => 195,  431 => 189,  429 => 188,  415 => 180,  408 => 176,  401 => 172,  394 => 168,  373 => 156,  348 => 140,  342 => 137,  338 => 135,  335 => 134,  325 => 129,  323 => 128,  320 => 127,  289 => 113,  286 => 112,  275 => 105,  270 => 102,  267 => 101,  262 => 98,  256 => 96,  233 => 87,  226 => 84,  207 => 75,  200 => 72,  181 => 65,  150 => 55,  81 => 23,  672 => 345,  668 => 344,  664 => 342,  651 => 337,  647 => 336,  644 => 335,  640 => 334,  631 => 327,  626 => 325,  613 => 320,  609 => 319,  602 => 317,  593 => 310,  591 => 309,  588 => 308,  585 => 307,  581 => 305,  577 => 303,  569 => 300,  563 => 298,  559 => 296,  557 => 295,  552 => 293,  548 => 292,  545 => 291,  541 => 290,  533 => 284,  531 => 283,  525 => 280,  519 => 278,  515 => 276,  509 => 272,  505 => 270,  499 => 268,  497 => 267,  489 => 262,  483 => 258,  479 => 256,  473 => 254,  471 => 253,  465 => 249,  463 => 248,  459 => 246,  454 => 244,  448 => 240,  438 => 236,  436 => 235,  428 => 230,  422 => 184,  418 => 224,  412 => 222,  410 => 221,  400 => 214,  397 => 213,  383 => 207,  376 => 205,  347 => 191,  329 => 131,  317 => 185,  313 => 183,  304 => 181,  295 => 178,  205 => 108,  77 => 20,  118 => 49,  113 => 38,  100 => 39,  389 => 160,  386 => 159,  380 => 160,  378 => 157,  371 => 156,  367 => 198,  361 => 146,  358 => 151,  345 => 147,  343 => 146,  340 => 145,  334 => 141,  331 => 140,  328 => 139,  326 => 138,  307 => 128,  302 => 125,  296 => 121,  293 => 120,  290 => 119,  281 => 114,  276 => 111,  259 => 103,  253 => 100,  248 => 94,  232 => 88,  222 => 83,  216 => 79,  213 => 78,  210 => 77,  197 => 71,  191 => 69,  184 => 101,  175 => 65,  172 => 62,  155 => 47,  152 => 46,  810 => 492,  807 => 491,  796 => 489,  792 => 488,  788 => 486,  775 => 485,  749 => 479,  746 => 478,  727 => 476,  710 => 475,  706 => 473,  702 => 472,  698 => 471,  694 => 470,  690 => 469,  686 => 468,  682 => 467,  679 => 466,  677 => 465,  660 => 340,  649 => 462,  634 => 456,  629 => 326,  625 => 453,  622 => 323,  620 => 451,  606 => 318,  601 => 446,  567 => 414,  549 => 411,  532 => 410,  529 => 409,  527 => 281,  522 => 279,  517 => 404,  188 => 102,  165 => 60,  363 => 153,  357 => 123,  353 => 193,  351 => 141,  344 => 119,  332 => 116,  327 => 114,  324 => 113,  321 => 135,  318 => 111,  315 => 125,  306 => 107,  303 => 122,  300 => 121,  297 => 179,  291 => 102,  288 => 176,  274 => 110,  265 => 105,  263 => 95,  255 => 101,  231 => 83,  212 => 78,  202 => 94,  185 => 66,  104 => 32,  58 => 25,  127 => 35,  110 => 28,  90 => 27,  76 => 31,  23 => 4,  70 => 19,  53 => 12,  34 => 5,  198 => 56,  194 => 70,  190 => 76,  186 => 53,  178 => 64,  174 => 65,  170 => 96,  161 => 63,  153 => 56,  134 => 47,  129 => 32,  84 => 24,  65 => 18,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 245,  453 => 199,  444 => 238,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 215,  398 => 129,  393 => 211,  387 => 164,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 197,  362 => 110,  360 => 109,  355 => 143,  341 => 189,  337 => 103,  322 => 101,  314 => 99,  312 => 124,  309 => 129,  305 => 95,  298 => 120,  294 => 90,  285 => 175,  283 => 115,  278 => 106,  268 => 85,  264 => 84,  258 => 94,  252 => 80,  247 => 78,  241 => 90,  229 => 85,  220 => 81,  214 => 69,  177 => 65,  169 => 60,  140 => 58,  132 => 51,  128 => 49,  107 => 36,  61 => 12,  273 => 174,  269 => 107,  254 => 92,  243 => 92,  240 => 86,  238 => 85,  235 => 89,  230 => 82,  227 => 86,  224 => 81,  221 => 77,  219 => 76,  217 => 75,  208 => 76,  204 => 72,  179 => 98,  159 => 90,  143 => 51,  135 => 53,  119 => 40,  102 => 33,  71 => 14,  67 => 18,  63 => 18,  59 => 14,  94 => 21,  89 => 20,  85 => 23,  75 => 19,  68 => 30,  56 => 16,  38 => 7,  26 => 4,  201 => 106,  196 => 92,  183 => 82,  171 => 61,  166 => 95,  163 => 53,  158 => 62,  156 => 58,  151 => 59,  142 => 59,  138 => 54,  136 => 71,  121 => 50,  117 => 39,  105 => 34,  91 => 33,  62 => 12,  49 => 14,  87 => 34,  31 => 4,  21 => 2,  25 => 4,  28 => 3,  24 => 1,  19 => 1,  93 => 27,  88 => 32,  78 => 17,  46 => 13,  44 => 9,  27 => 3,  79 => 21,  72 => 17,  69 => 16,  47 => 8,  40 => 7,  37 => 7,  22 => 3,  246 => 93,  157 => 89,  145 => 74,  139 => 49,  131 => 45,  123 => 42,  120 => 31,  115 => 43,  111 => 47,  108 => 36,  101 => 31,  98 => 45,  96 => 30,  83 => 33,  74 => 14,  66 => 24,  55 => 16,  52 => 12,  50 => 22,  43 => 9,  41 => 8,  35 => 9,  32 => 5,  29 => 3,  209 => 82,  203 => 73,  199 => 93,  193 => 73,  189 => 66,  187 => 75,  182 => 87,  176 => 63,  173 => 85,  168 => 61,  164 => 59,  162 => 59,  154 => 60,  149 => 40,  147 => 54,  144 => 42,  141 => 51,  133 => 55,  130 => 46,  125 => 51,  122 => 41,  116 => 39,  112 => 36,  109 => 27,  106 => 51,  103 => 32,  99 => 31,  95 => 28,  92 => 43,  86 => 28,  82 => 19,  80 => 32,  73 => 20,  64 => 17,  60 => 14,  57 => 11,  54 => 10,  51 => 13,  48 => 12,  45 => 10,  42 => 11,  39 => 10,  36 => 5,  33 => 4,  30 => 3,);
    }
}
