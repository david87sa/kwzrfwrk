<?php

/* KweizarPageBundle:Author:index.html.twig */
class __TwigTemplate_aca89840bb7523e7a6fc78d3fb1e19d717a368041aac460b31408f3cb1bc3639 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'jquery' => array($this, 'block_jquery'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_jquery($context, array $blocks = array())
    {
        // line 4
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/jquery-2.1.1.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/components/authormain.js"), "html", null, true);
        echo "\"></script>
";
    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        // line 9
        echo "    
    <h2 class=\"main_title\">Author Page</h2>
    <div id=\"main_container\">
        <div id=\"components\" class=\"container\">
            <ul class=\"components\">
                <h3>Existing Components</h3>
                ";
        // line 15
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["elements"]) ? $context["elements"] : $this->getContext($context, "elements")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 16
            echo "                    <li><span>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["element"]) ? $context["element"] : $this->getContext($context, "element")), "description"), "html", null, true);
            echo ": ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["element"]) ? $context["element"] : $this->getContext($context, "element")), "content"), "html", null, true);
            echo "</span>
                        <a href=\"";
            // line 17
            echo $this->env->getExtension('routing')->getPath("kweizar_page_section_add");
            echo "\" class=\"addsection\" component-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["element"]) ? $context["element"] : $this->getContext($context, "element")), "id"), "html", null, true);
            echo "\">Add Section</a>
                        <a class=\"delete\" href=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("kweizar_page_author_delete", array("id" => $this->getAttribute((isset($context["element"]) ? $context["element"] : $this->getContext($context, "element")), "id"))), "html", null, true);
            echo "\">Remove</a>
                    ";
            // line 19
            $this->env->loadTemplate("KweizarPageBundle:Author:sectionForm.html.twig")->display($context);
            echo "    
                    </li>     
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "            </ul>
        </div>    
    </div>
    <div id=\"component_form\" class=\"container\">
        <h3>Add Component</h3>
        ";
        // line 27
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("kweizar_page_author_add")));
        echo "
            ";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "

            ";
        // line 30
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description"), 'row');
        echo "
            ";
        // line 31
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "content"), 'row');
        echo "
        ";
        // line 32
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
    ";
        // line 34
        $this->env->loadTemplate("KweizarPageBundle:Author:sectionTypeForm.html.twig")->display($context);
        // line 35
        echo "    
    <div id=\"section_form\" class=\"hidden container\">
        <h3>Add Section</h3>
        ";
        // line 38
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("kweizar_page_section_add")));
        echo "
            ";
        // line 39
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), 'errors');
        echo "
            ";
        // line 40
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), "title"), 'row');
        echo "
            ";
        // line 41
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), "subTitle"), 'row');
        echo "
            ";
        // line 42
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), "sectionType"), 'row');
        echo "
        ";
        // line 43
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["sectionform"]) ? $context["sectionform"] : $this->getContext($context, "sectionform")), 'form_end');
        echo "
        
            <button id=\"addSectionType\">Add Type</button>
    </div>
    <div id=\"element_form\" class=\"hidden container\">
        <h3>Add Element</h3>
        ";
        // line 49
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("kweizar_page_element_add")));
        echo "
            ";
        // line 50
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), 'errors');
        echo "
            ";
        // line 51
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), "imgSrc"), 'row');
        echo "
            ";
        // line 52
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), "title"), 'row');
        echo "
            ";
        // line 53
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), "description"), 'row');
        echo "
            ";
        // line 54
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), "destinationType"), 'row');
        echo "
            ";
        // line 55
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), "destinationContent"), 'row');
        echo "
        ";
        // line 56
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["elementform"]) ? $context["elementform"] : $this->getContext($context, "elementform")), 'form_end');
        echo "
    </div>
    <style>
       h2, h3, span, button, label, i, b, a {
            font-family: monospace;
        }
        .main_title{
            text-align: center;
        }
        .floating_form {
            display: inline-block;
            width: 200px;
            height: 66px;
            position: absolute;
        }
         .hidden{
            display: none!important;
        }
        .container {
            display: inline-block;
            margin: 0 auto;
        }
        div#main_container {
            width: 70%;
            float: right;
            border: darkgray solid 1px;
        }
        label {
            width: 95px;
            display: inline-block;
            height: 25px;
            text-align: right;
            margin: 5px;
        }
        input,select {
            height: 25px;
            width: 250px;
        }
        button {
            height: 32px;
            width: 121px;
            float: right;
        }
        li {
            list-style: none;
        }
        div#section_form {
            width: 361px;
            padding: 10px;
            border: darkgray solid 2px;
            height: 158px;
            background-color: white;
        }
        div#element_form {
            width: 375px;
            padding: 10px;
            border: darkgray solid 2px;
            height: 280px;
            background-color: white;
        }
        span {
            height: 25px;
            display: inline-block;
            font-size: 17px;
        }
        a:link {
            color: #3f3f3f;
            text-decoration: none;
            margin: 0 4px;
            font-style: italic;
        }
        a:visited {
            color: #3f3f3f;
            text-decoration: none;
            margin: 0 4px;
            font-style: italic;
        }
        a:hover {
            color: #3f3f3f;
            text-decoration: underline;
            margin: 0 4px;
            font-style: italic;
        }
        div#component_form {
            float: left;
            border: darkgrey solid 1px;
            padding: 10px;
            margin-bottom: 12px;
        }
        div#sectionTypes {
            float: left;
            border: darkgrey solid 1px;
            padding: 10px;
        }
        #sectiontype_form button {
            width: 150px;
        }
        i.prefix_title {
            color: #3f3f3f;
            margin: 0 5px;
            font-size: 13px;
        }
        div#main_container .container {
            width: 100%;
        }
    </style>
    <script>
        
        \$(\".addsection\").click(function(event){
            event.preventDefault();
            url = \$(this).attr(\"href\")+\"?parentid=\"+\$(this).attr(\"component-id\");
            position = \$(this).position();
            \$(\"#section_form\").removeClass(\"hidden\").addClass(\"floating_form\");
            \$(\"#section_form\").css(\"right\",\"15px\");
            \$(\"#section_form\").css(\"top\",position.top+20);
            \$(\"#section_form form\").attr(\"action\",url);
        });
        \$(\".addelement\").click(function(event){
            event.preventDefault();
            url = \$(this).attr(\"href\")+\"?sectionid=\"+\$(this).attr(\"section-id\");
            position = \$(this).position();
            \$(\"#element_form\").removeClass(\"hidden\").addClass(\"floating_form\");
            \$(\"#element_form\").css(\"right\",\"15px\");
            \$(\"#element_form\").css(\"top\",position.top+20);
            \$(\"#element_form form\").attr(\"action\",url);
        });
        
    </script>
 ";
    }

    public function getTemplateName()
    {
        return "KweizarPageBundle:Author:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  198 => 56,  194 => 55,  190 => 54,  186 => 53,  178 => 51,  174 => 50,  170 => 49,  161 => 43,  153 => 41,  134 => 34,  129 => 32,  84 => 18,  65 => 18,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  107 => 36,  61 => 17,  273 => 96,  269 => 94,  254 => 92,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 56,  135 => 53,  119 => 42,  102 => 32,  71 => 16,  67 => 15,  63 => 15,  59 => 14,  94 => 28,  89 => 20,  85 => 25,  75 => 17,  68 => 14,  56 => 15,  38 => 6,  26 => 6,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 67,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 35,  121 => 30,  117 => 44,  105 => 22,  91 => 27,  62 => 23,  49 => 19,  87 => 25,  31 => 7,  21 => 2,  25 => 3,  28 => 6,  24 => 5,  19 => 2,  93 => 28,  88 => 19,  78 => 17,  46 => 9,  44 => 12,  27 => 4,  79 => 18,  72 => 16,  69 => 19,  47 => 9,  40 => 7,  37 => 5,  22 => 2,  246 => 90,  157 => 42,  145 => 39,  139 => 45,  131 => 52,  123 => 47,  120 => 40,  115 => 43,  111 => 37,  108 => 36,  101 => 32,  98 => 31,  96 => 31,  83 => 25,  74 => 14,  66 => 24,  55 => 15,  52 => 14,  50 => 10,  43 => 8,  41 => 7,  35 => 8,  32 => 4,  29 => 3,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 52,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 58,  149 => 40,  147 => 58,  144 => 49,  141 => 38,  133 => 55,  130 => 41,  125 => 31,  122 => 43,  116 => 28,  112 => 27,  109 => 34,  106 => 36,  103 => 32,  99 => 31,  95 => 28,  92 => 21,  86 => 28,  82 => 22,  80 => 19,  73 => 19,  64 => 14,  60 => 6,  57 => 11,  54 => 15,  51 => 14,  48 => 12,  45 => 17,  42 => 7,  39 => 9,  36 => 5,  33 => 4,  30 => 7,);
    }
}
