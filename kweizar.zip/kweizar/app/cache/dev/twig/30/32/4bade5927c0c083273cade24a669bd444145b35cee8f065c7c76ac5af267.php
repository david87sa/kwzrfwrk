<?php

/* KweizarPageBundle:emails:contactEmail.html.twig */
class __TwigTemplate_30324bade5927c0c083273cade24a669bd444145b35cee8f065c7c76ac5af267 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "You have received a contact email request from ";
        echo twig_escape_filter($this->env, (isset($context["email"]) ? $context["email"] : $this->getContext($context, "email")), "html", null, true);
        echo "
this is the content of the email:
";
        // line 4
        echo twig_escape_filter($this->env, (isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "html", null, true);
        echo "
";
    }

    public function getTemplateName()
    {
        return "KweizarPageBundle:emails:contactEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 4,  19 => 2,);
    }
}
